# HospitalMS

To Import Hospital Management System,
Firstly you need to extract libraries and and database,
Import given project in NetBeans and add Libraries/JAR files,
Open XAMP open PHP my server and import database by creating one with same name first.
